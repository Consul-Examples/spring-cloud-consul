package com.rudra.aks.consul;

public class ScheduleConfig {

}
